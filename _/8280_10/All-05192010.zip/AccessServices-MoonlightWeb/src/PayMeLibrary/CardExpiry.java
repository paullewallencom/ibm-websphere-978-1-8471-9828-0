/**
 * CardExpiry.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf230904.14 v13009114817
 */

package PayMeLibrary;

public class CardExpiry  {
    private java.lang.Integer month;
    private java.lang.Integer year;

    public CardExpiry() {
    }

    public java.lang.Integer getMonth() {
        return month;
    }

    public void setMonth(java.lang.Integer month) {
        this.month = month;
    }

    public java.lang.Integer getYear() {
        return year;
    }

    public void setYear(java.lang.Integer year) {
        this.year = year;
    }

}
