/**
 * Rejection.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf230904.14 v13009114817
 */

package PayMeLibrary;

public class Rejection  {
    private java.lang.String reasonCode;
    private java.lang.String reasonDesc;
    private java.lang.String action;

    public Rejection() {
    }

    public java.lang.String getReasonCode() {
        return reasonCode;
    }

    public void setReasonCode(java.lang.String reasonCode) {
        this.reasonCode = reasonCode;
    }

    public java.lang.String getReasonDesc() {
        return reasonDesc;
    }

    public void setReasonDesc(java.lang.String reasonDesc) {
        this.reasonDesc = reasonDesc;
    }

    public java.lang.String getAction() {
        return action;
    }

    public void setAction(java.lang.String action) {
        this.action = action;
    }

}
